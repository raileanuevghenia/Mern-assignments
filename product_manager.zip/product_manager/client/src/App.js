import React from 'react';
import { Router } from '@reach/router';
import Main from './views/Main';
import Edit from './views/Edit';
import Update from './views/Update';
import './App.css';

function App() {
  return (
    <div className="App">
      <Router>
        <Main path="/products/"/>
        <Edit path="/products/:id"/>
        <Update path="/products/:id/edit"/>
      </Router>
    </div>
  );
}

export default App;
